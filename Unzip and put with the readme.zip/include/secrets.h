#pragma once

#define WIFI_SSID "JS Wifi"
#define WIFI_PASSWORD "98819881xyz"
#define UDP_HOST "192.168.43.253"
#define UDP_PORT 4210

